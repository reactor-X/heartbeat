console.log('Welcome to use this boilerplate');
//# sourceMappingURL=example.js.map