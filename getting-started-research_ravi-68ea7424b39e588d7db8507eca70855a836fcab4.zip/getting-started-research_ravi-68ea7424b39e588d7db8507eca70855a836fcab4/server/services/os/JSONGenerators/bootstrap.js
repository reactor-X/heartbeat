var ubuntu=require ('./UbuntuJsonGenerator.js');

var primary_json_generator={
	'ubuntu':ubuntu
}

module.exports = primary_json_generator