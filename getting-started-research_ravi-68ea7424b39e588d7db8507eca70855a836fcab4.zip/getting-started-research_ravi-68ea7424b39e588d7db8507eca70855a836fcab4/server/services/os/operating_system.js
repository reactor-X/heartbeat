var ubuntu=require ('./ubuntu');
var terminal={
'ubuntu':ubuntu,
}
var operating_system={
'terminal':terminal
}
module.exports = operating_system