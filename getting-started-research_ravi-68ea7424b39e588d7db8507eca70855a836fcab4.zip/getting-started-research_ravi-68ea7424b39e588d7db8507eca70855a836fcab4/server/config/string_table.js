var string_table = {
    'error': {
        'invalid_credentials': 'Invalid Username or Password',
        'server_error_unknown': 'Something happened on our end. Please try again later.'
    },
    'success': {
        'signup_success': 'Successfully signed up.'
    }
}

module.exports = string_table